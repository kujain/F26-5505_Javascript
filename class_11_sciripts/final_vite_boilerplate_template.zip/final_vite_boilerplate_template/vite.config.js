// vite.config.js
import { defineConfig } from 'vite';
import legacy from '@vitejs/plugin-legacy';

export default defineConfig({
    plugins: [
        legacy({
          // Specify older browser query targets using Browserslist syntax
          targets: ['chrome >= 49', 'firefox >= 52', 'safari >= 10', 'ie >= 11'],          
          // Automatically inject required polyfills for older syntax
          modernPolyfills: true, 
          renderLegacyChunks: true
        }),
    ],
    build: {
        target: 'es2015',
        assetsDir: 'assets',
        outDir: 'dist',
        emptyOutDir: true
    },
    server: {
        port: 3000, // Change this if you want a different dev server port
      }
});
